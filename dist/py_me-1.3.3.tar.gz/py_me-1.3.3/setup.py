from setuptools import setup, find_packages

setup(
    name='py_me',
    version='1.3.3',
    packages=find_packages(),
    description='Biblioteca com módulos musicais e gráficos',
    author='isaias da silva nobrega',
    author_email='isaiasdasilvanobrega@gmail.com',
)